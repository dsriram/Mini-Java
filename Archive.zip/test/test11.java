class one {
  public static void main(String[] args) {
  }
}
class two {
  public character func() {
    boolean x;
    int y;
    x = true && y;
    return x;
  }
}