class one {
  public static void main(String[] args) {
  }
}
class two {
  int func;

  public character func() {
    return 0;
  }
}