class one {
  public static void main(String[] args) {
  }
}
class two {
  int x;
  int y;
  int[] z;
  
  public int[] fun() {
    y = z.length;
    return y;
  }

  public character fun2(int[] x) {
    return x[1 + 2<2 + 3];
  }
}