class one {
  public static void main(String[] args) {
  }
}
class two {
  public int func() {
    return 0;
  }
}
class three {
  public int func() {
    return 0;
  }
}