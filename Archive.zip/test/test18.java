class Factorial {
    public static void main(String[] args) {
        System.out.println(1);
        if (1<2 && true)
            alpha = b;
        else {
            System.out.println(1+2);
        }
    }
}

class Fact extends AnotherClass {
    public int func() {
        return 0;
    }

    public int ComputeFac(int num) {
        int num_aux;
        booleana yy_var;
        boolean yy_var2;
        int[] yy_var3;
        
        ff = new int[10];
        fg = true[2];
        fg[1] = 2-3;
        
        if (num < 1)
            num_aux = 1;
        else {
            num_aux1 = num * (this.ComputeFac(num-1));
            num_aux2 = num * (this.ComputeFac(num-1));
        }
        num_aux3 = num * (this.ComputeFac(num-1));
        while (this.length < 0)
            if (num_aux < num)
                num_aux4 = num * (this.ComputeFac(num-1));
            else
                y = 1;
        
        System.out.println(1+2+3*4);

        return num_aux;
    }
}

class Fact2 extends Fact {
    public int ComputeFac(int num, booool numssss, boolean bool) {
        int x;
        return 0;
    }
}


class Fact3 extends Fact {
    bool x;
    boolean y;
    int method1;
    public int method1() {
        return 0;
    }
    public int[] method2() {
        return 0;
    }
    public some_type method3() {
        int zzz;
        zzz = this.method1();
        return 0;
    }
    public bool method2() {
        return 1;
    }
}


class Fact4 extends Fact3 {
    public int method1() {
        return 0;
    }
}
