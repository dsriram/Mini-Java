class one {
  public static void main(String[] args) {
  }
}
class two {
  public character func() {
    int x;
    int y;
    x = y < true;
    return x;
  }
}