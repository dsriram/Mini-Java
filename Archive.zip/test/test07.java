class one {
  public static void main(String[] args) {
  }
}
class two {
  public int[] func() {
    y = z.length;
    return y;
  }

  public character func() {
    return 0;
  }
}