class one {
  public static void main(String[] args) {
    if (args.length < 2)
      System.out.println(1 + 2 * 3);
    else
      {
        args[0] = args[1];
      }
  }
}
class two {
}
class three extends two {
  
}